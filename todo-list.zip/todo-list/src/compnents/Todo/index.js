import React, { useState } from "react";
import List from "./List";

function Todo() {

  const [taskname, setTaskname] = useState("");
  const [lists, setLists] = useState([]);
  
  const addList = () => {
      console.log(taskname);
      let listItem = {
          "name": taskname,
          "state": 'active'
      }

      setLists([...lists, listItem]);
      console.log(lists);
  }

  return (
    <div className='container text-center'>
      <h1>TO DO LIST!</h1>
      <div className="task-form">
            <input type="text" placeholder="New Task" onChange={(event) => setTaskname(event.target.value)} className="form-control" />
            <div>&nbsp;</div>
            <button type="button" onClick={addList} className="btn btn-primary">Add</button>
      </div>
      <div className="task-list">
            <List items={lists} />
      </div>

    </div>
  );
}

export default Todo;
